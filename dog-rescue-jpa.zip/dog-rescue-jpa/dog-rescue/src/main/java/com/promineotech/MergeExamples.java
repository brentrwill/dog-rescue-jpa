package com.promineotech;

import java.lang.reflect.Field;

public class MergeExamples {

	public Object merge(Object src, Object target) throws Exception {
		Class<?> clazz = src.getClass();
		for (Field srcField : clazz.getDeclaredFields()) {
			srcField.setAccessible(true);
			for (Field targetField : target.getClass().getDeclaredFields()) {
				targetField.setAccessible(true);
				String localName = srcField.getName();
				String remoteName = targetField.getName();

				if (localName != null && remoteName != null) {
					if (localName.equalsIgnoreCase(remoteName)) {
						Object srcValue = srcField.get(src);
						/**
						 * Make we don't have an empty source value. This is entirely possible as we may
						 * only want to update specific fields
						 */
						if (srcValue != null) {
							if (targetField.get(target) == null) {
								targetField.set(target, srcValue);
							} else {
								/**
								 * We check the type of property we are setting, i.e., String, int, long or
								 * boolean
								 */
								Object targetValue = targetField.get(target);
								if (targetValue instanceof String) {
									String targetStr = (String) targetValue;
									String srcStr = (String) srcValue;
									if (!srcStr.contains(targetStr)) {
										targetField.set(target, srcValue);
									}
								} else if (targetValue instanceof Long) {
									Long targetLong = (Long) targetValue;
									Long srcLong = (Long) srcValue;
									if (srcLong.longValue() != targetLong.longValue()) {
										targetField.set(target, srcValue);
									}
								} else if (targetValue instanceof Integer) {
									Integer targetInt = (Integer) targetValue;
									Integer srcInt = (Integer) srcValue;
									if (srcInt.intValue() != targetInt.intValue()) {
										targetField.set(target, srcValue);
									}
								} else if (targetValue instanceof Boolean) {
									Boolean targetInt = (Boolean) targetValue;
									Boolean srcInt = (Boolean) srcValue;
									if (srcInt.booleanValue() != targetInt.booleanValue()) {
										targetField.set(target, srcValue);
									}
								}
							}
						}
					}
				}
			}
		}
		return target;
	}

	/**
	 * This merge is design to do special types of merges, for example, if you want
	 * to move data from 1 Object to another.
	 */
	public Object specialMerge(Object src, Object target) throws Exception {
		if (src instanceof Instructor) {
			if (target instanceof Student) {
				/**
				 * This indicates that we want to pull data from the Instructor Object and set
				 * that data in the Student.
				 * 
				 * This example will take the Instructor's name and copies it to the Student's
				 * name.
				 */
				String name = ((Instructor) src).getName();
				((Student) target).setStudentName(name);
			}
		}

		return target;
	}

	public static void main(String[] args) {
		try {

			MergeExamples examples = new MergeExamples();

			/**
			 * This example takes the newObjetWithUpdates and merges it into existingObject
			 * and that will be the data that is updates.
			 */
			BallRoom newObjetWithUpdates = new BallRoom();
			newObjetWithUpdates.setName("The new name");

			BallRoom existingObject = new BallRoom();
			existingObject.setName("The old Name");
			existingObject.setLocation("1234 West 6789 North");

			System.out.println("---------- Before Merge -------------------");
			System.out.println(newObjetWithUpdates);
			System.out.println(existingObject);
			System.out.println("-------------------------------------------");

			existingObject = (BallRoom) examples.merge(newObjetWithUpdates, existingObject);
			System.out.println(existingObject);
			System.out.println("-------------------------------------------");

			/**
			 * This example is to show how we can do separate Objects with the same
			 * properties.
			 */
			Instructor instructor = new Instructor();
			instructor.setName("This name will end up in the BallRoom");

			System.out.println("---------- Before Merge -------------------");
			System.out.println(existingObject);
			System.out.println(instructor);
			System.out.println("-------------------------------------------");

			existingObject = (BallRoom) examples.merge(instructor, existingObject);
			System.out.println(existingObject);
			System.out.println("-------------------------------------------");

			/**
			 * This example shows how we can merge 2 different Objects with 2 separate
			 * properties.
			 */
			instructor.setName("Beth Johnson");
			Student student = new Student();
			student.setStudentName("Name to be replaced");
			student.setAddress("555 South 222 East");

			System.out.println("---------- Before Merge -------------------");
			System.out.println(instructor);
			System.out.println(student);
			System.out.println("-------------------------------------------");

			student = (Student) examples.specialMerge(instructor, student);
			System.out.println(student);
			System.out.println("-------------------------------------------");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static class BallRoom {
		private String name;
		private String location;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		@Override
		public String toString() {
			return "BallRoom [name=" + name + ", location=" + location + "]";
		}
	}

	public static class Instructor {
		private String name;
		private String address;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		@Override
		public String toString() {
			return "Instructor [name=" + name + ", address=" + address + "]";
		}
	}

	public static class Student {
		private String studentName;
		private String address;

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String name) {
			this.studentName = name;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		@Override
		public String toString() {
			return "Student [studentName=" + studentName + ", address=" + address + "]";
		}
	}

}
