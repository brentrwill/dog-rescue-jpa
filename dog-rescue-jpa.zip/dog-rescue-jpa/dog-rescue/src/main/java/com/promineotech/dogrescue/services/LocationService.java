package com.promineotech.dogrescue.services;

import java.lang.reflect.Field;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.promineotech.dogrescue.controller.model.LocationData;
import com.promineotech.dogrescue.dao.LocationDao;
import com.promineotech.dogrescue.entity.Location;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LocationService {

	@Autowired
	private LocationDao locationDao;
	private org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LocationService.class);

	public LocationData saveLocation(LocationData locationData) {
		try {
			Location location = findOrCreateLocation(locationData);
			if (location == null) {
				location = locationData.toLocation();
				location = locationDao.save(location);
				locationData = new LocationData(location);
			} else {
				location = (Location) mergeData(locationData, location, "dog");
				location = locationDao.saveAndFlush(location);
				locationData = new LocationData(location);
			}
		} catch (Exception e) {
			throw new NoSuchElementException("Error processing save/update location", e);
		}
		return locationData;
	}

	public LocationData updateLocationName(String name, Long id) {
		LocationData data = null;
		try {
			locationDao.updateLocationName(name, id);
			data = findLocById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	private Location findOrCreateLocation(LocationData locatoinData) {
		Location location = null;
		try {
			location = findLocationById(locatoinData.getLocationId());
		} catch (Exception e) {
			log.debug(e.getMessage());
		}
		return location;
	}

	public LocationData findLocById(long locationId) {
		LocationData data = null;
		try {
			Optional<Location> results = locationDao.findById(locationId);
			Location location = results.orElse(null);
			if (location == null) {
				throw new NoSuchElementException("No Location existed with the Id : " + locationId);
			} else {
				data = new LocationData(location);
				return data;
				// return (LocationData) mergeData(location, data, "dog");
			}
		} catch (Exception e) {
			throw new NoSuchElementException("Error processing location with Id : " + locationId);
		}
	}

	public void deleteLocById(long locationId) {
		try {
			Optional<Location> results = locationDao.findById(locationId);
			Location location = results.orElse(null);
			if (location == null) {
				throw new NoSuchElementException("No Location existed with the Id : " + locationId);
			} else {
				locationDao.deleteById(locationId);
			}
		} catch (Exception e) {
			throw new NoSuchElementException("Error processing location with Id : " + locationId);
		}
	}

	private Location findLocationById(long locationId) {
		Optional<Location> results = locationDao.findById(locationId);
		Location location = results.orElse(null);
		if (location == null) {
			throw new NoSuchElementException("No Location existed with the Id : " + locationId);
		} else {
			return location;
		}
	}

	public List<Location> getAllLocations() {
		return locationDao.findAll(Sort.by(Sort.Direction.ASC, "state"));
	}

	public Object mergeData(Object src, Object target, String propertyToSkip) throws Exception {
		Class<?> clazz = src.getClass();
		for (Field srcField : clazz.getDeclaredFields()) {
			srcField.setAccessible(true);
			for (Field targetField : target.getClass().getDeclaredFields()) {
				targetField.setAccessible(true);
				String localName = srcField.getName();
				String remoteName = targetField.getName();

				if (!localName.contains(propertyToSkip)) {
					if (localName != null && remoteName != null) {
						if (localName.equalsIgnoreCase(remoteName)) {
							Object srcValue = srcField.get(src);
							if (srcValue != null) {
								if (targetField.get(target) == null) {
									targetField.set(target, srcValue);
								} else {
									Object targetValue = targetField.get(target);
									if (targetValue instanceof String) {
										String targetStr = (String) targetValue;
										String srcStr = (String) srcValue;
										if (!srcStr.contains(targetStr)) {
											targetField.set(target, srcValue);
										}
									} else if (targetValue instanceof Long) {
										Long targetLong = (Long) targetValue;
										Long srcLong = (Long) srcValue;
										if (srcLong.longValue() != targetLong.longValue()) {
											targetField.set(target, srcValue);
										}
									} else if (targetValue instanceof Integer) {
										Integer targetInt = (Integer) targetValue;
										Integer srcInt = (Integer) srcValue;
										if (srcInt.intValue() != targetInt.intValue()) {
											targetField.set(target, srcValue);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return target;
	}

	public Object mergeDataTest(Object src, Object target) throws Exception {
		Class<?> clazz = src.getClass();
		for (Field srcField : clazz.getDeclaredFields()) {
			srcField.setAccessible(true);
			for (Field targetField : target.getClass().getDeclaredFields()) {
				targetField.setAccessible(true);
				String localName = srcField.getName();
				String remoteName = targetField.getName();

				if (localName != null && remoteName != null) {
					if (localName.equalsIgnoreCase(remoteName)) {
						Object srcValue = srcField.get(src);
						Object targetValue = targetField.get(target);
						if (targetField.get(target) == null) {
							targetField.set(target, srcValue);
						} else {
							targetField.set(target, srcValue);
						}
					}
				}
			}
		}
		return target;
	}

	public static void main(String[] args) {
		try {

			LocationService service = new LocationService();
			BallRoom room = new BallRoom();
			room.setName("West Wing");
			room.setReserved(false);
			room.setLocation("North Building.");

			Instructor instructor = new Instructor();
			instructor.setName("Dave Smith");
			instructor.setAddress("West Center");

			service.mergeDataTest(instructor, room);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static class BallRoom {
		private String name;
		private String location;
		private boolean isReserved;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public boolean isReserved() {
			return isReserved;
		}

		public void setReserved(boolean isReserved) {
			this.isReserved = isReserved;
		}
	}

	public static class Instructor {
		private String name;
		private String address;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}
	}
}